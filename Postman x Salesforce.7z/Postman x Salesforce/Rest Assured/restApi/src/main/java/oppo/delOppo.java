package oppo;

public class delOppo {

}
